
# República da Praia — Backend do Chat IA

## 1) Requisitos
- Node.js 18+ (ou 20+)

## 2) Instalar
```bash
npm install
```

## 3) Configurar variáveis
Crie um arquivo `.env` (ou configure no Render/Railway):
```bash
OPENAI_API_KEY=coloque_sua_chave_aqui
OPENAI_MODEL=gpt-5-mini
```

## 4) Rodar local
```bash
npm start
```
Vai subir em `http://localhost:8787`

## 5) No site (front)
No HTML, o chat chama por padrão:
- `CONFIG.API_BASE + "/api/chat"`

Então:
- se você hospedar esse backend, defina `CONFIG.API_BASE` com a URL pública dele.
- se você rodar junto do site, pode deixar `/api/chat`.
